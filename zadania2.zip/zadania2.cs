using System;
 
class Animal
{
    private string species;
    private int age;
    private double weight;
    private bool isCarnivorous;
    private string habitat;
    private string color;
    private bool isEndangered;
    private int numberOfLegs;
 
    // Constructor
    public Animal(string species, int age, double weight, bool isCarnivorous,
                  string habitat, string color, bool isEndangered, int numberOfLegs)
    {
        this.species = species;
        this.age = age;
        this.weight = weight;
        this.isCarnivorous = isCarnivorous;
        this.habitat = habitat;
        this.color = color;
        this.isEndangered = isEndangered;
        this.numberOfLegs = numberOfLegs;
    }
 
    // Properties
    public string Species
    {
        get { return species; }
        set { species = value; }
    }
 
    public int Age
    {
        get { return age; }
        set { age = value; }
    }
 
    // Additional functionality
    public void DisplayInfo()
    {
        Console.WriteLine($"Species: {species}, Age: {age}, Weight: {weight} kg");
    }
}
 
class Car
{
    private string make;
    private string model;
    private int year;
    private double engineSize;
    private bool isAutomatic;
    private string color;
    private int numberOfDoors;
    private bool isElectric;
 
    // Constructor
    public Car(string make, string model, int year, double engineSize,
               bool isAutomatic, string color, int numberOfDoors, bool isElectric)
    {
        this.make = make;
        this.model = model;
        this.year = year;
        this.engineSize = engineSize;
        this.isAutomatic = isAutomatic;
        this.color = color;
        this.numberOfDoors = numberOfDoors;
        this.isElectric = isElectric;
    }
 
    // Properties
    public string Make
    {
        get { return make; }
        set { make = value; }
    }
 
    public string Model
    {
        get { return model; }
        set { model = value; }
    }
 
    // Additional functionality
    public void StartEngine()
    {
        Console.WriteLine("The car engine is started.");
    }
}
 
class Person
{
    private string name;
    private int age;
    private string address;
    private double height;
    private bool hasPet;
    private string occupation;
    private bool isStudent;
    private bool isEmployed;
 
    // Constructor
    public Person(string name, int age, string address, double height,
                  bool hasPet, string occupation, bool isStudent, bool isEmployed)
    {
this.name = name;
        this.age = age;
        this.address = address;
        this.height = height;
        this.hasPet = hasPet;
        this.occupation = occupation;
        this.isStudent = isStudent;
        this.isEmployed = isEmployed;
    }
 
    // Properties
    public string Name
    {
        get { return name; }
        set { name = value; }
    }
 
    public int Age
    {
        get { return age; }
        set { age = value; }
    }
 
    // Additional functionality
    public void IntroduceYourself()
    {
        Console.WriteLine($"Hello, I am {name}.");
    }
}
 
class MainClass
{
    public static void Main(string[] args)
    {
        Animal lion = new Animal("Lion", 5, 180.5, true, "Grassland", "Yellow", false, 4);
        Car toyota = new Car("Toyota", "Camry", 2022, 2.5, true, "Blue", 4, false);
        Person john = new Person("John Doe", 30, "123 Main St", 175.0, true, "Engineer", false, true);
 
        // Functionality for Animal class
        lion.DisplayInfo();
 
        // Functionality for Car class
        toyota.StartEngine();
 
        // Functionality for Person class
        john.IntroduceYourself();
    }
}