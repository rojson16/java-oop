class Animal {
    private species: string;
    private age: number;
    private weight: number;
    private isCarnivorous: boolean;
    private habitat: string;
    private color: string;
    private isEndangered: boolean;
    private numberOfLegs: number;
 
    // Constructor
    constructor(
        species: string,
        age: number,
        weight: number,
        isCarnivorous: boolean,
        habitat: string,
        color: string,
        isEndangered: boolean,
        numberOfLegs: number
    ) {
        this.species = species;
        this.age = age;
        this.weight = weight;
        this.isCarnivorous = isCarnivorous;
        this.habitat = habitat;
        this.color = color;
        this.isEndangered = isEndangered;
        this.numberOfLegs = numberOfLegs;
    }
 
    // Getter and Setter for 'species'
    getSpecies(): string {
        return this.species;
    }
 
    setSpecies(newSpecies: string): void {
        this.species = newSpecies;
    }
 
    // Getter and Setter for 'age'
    getAge(): number {
        return this.age;
    }
 
    setAge(newAge: number): void {
        this.age = newAge;
    }
 
    // Additional functionality
    displayInfo(): void {
        console.log(`Species: ${this.species}, Age: ${this.age}, Weight: ${this.weight} kg`);
    }
}
 
class Car {
    private make: string;
    private model: string;
    private year: number;
    private engineSize: number;
    private isAutomatic: boolean;
    private color: string;
    private numberOfDoors: number;
    private isElectric: boolean;
 
    // Constructor
    constructor(
        make: string,
        model: string,
        year: number,
        engineSize: number,
        isAutomatic: boolean,
        color: string,
        numberOfDoors: number,
        isElectric: boolean
    ) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.engineSize = engineSize;
        this.isAutomatic = isAutomatic;
        this.color = color;
        this.numberOfDoors = numberOfDoors;
        this.isElectric = isElectric;
    }
 
    // Getter and Setter for 'make'
    getMake(): string {
        return this.make;
    }
 
    setMake(newMake: string): void {
        this.make = newMake;
    }
 
    // Getter and Setter for 'model'
    getModel(): string {
        return this.model;
    }
 
    setModel(newModel: string): void {
        this.model = newModel;
    }
 
    // Additional functionality
    startEngine(): void {
        console.log("The car engine is started.");
    }
}
 
class Person {
    private name: string;
    private age: number;
    private address: string;
    private height: number;
    private hasPet: boolean;
    private occupation: string;
    private isStudent: boolean;
    private isEmployed: boolean;
 
    // Constructor
    constructor(
        name: string,
        age: number,
        address: string,
        height: number,
        hasPet: boolean,
        occupation: string,
        isStudent: boolean,
        isEmployed: boolean
    ) {
this.name = name;
        this.age = age;
        this.address = address;
        this.height = height;
        this.hasPet = hasPet;
        this.occupation = occupation;
        this.isStudent = isStudent;
        this.isEmployed = isEmployed;
    }
 
    // Getter and Setter for 'name'
    getName(): string {
return this.name;
    }
 
    setName(newName: string): void {
this.name = newName;
    }
 
    // Getter and Setter for 'age'
    getAge(): number {
        return this.age;
    }
 
    setAge(newAge: number): void {
        this.age = newAge;
    }
 
    // Additional functionality
    introduceYourself(): void {
console.log(`Hello, I am ${this.name}.`);
    }
}
 
// MainClass
const lion = new Animal("Lion", 5, 180.5, true, "Grassland", "Yellow", false, 4);
const toyota = new Car("Toyota", "Camry", 2022, 2.5, true, "Blue", 4, false);
const john = new Person("John Doe", 30, "123 Main St", 175.0, true, "Engineer", false, true);
 
// Functionality for Animal class
lion.displayInfo();
 
// Functionality for Car class
toyota.startEngine();
 
// Functionality for Person class
john.introduceYourself();